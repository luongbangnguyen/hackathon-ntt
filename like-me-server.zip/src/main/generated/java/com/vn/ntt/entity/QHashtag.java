package com.vn.ntt.entity;

import static com.mysema.query.types.PathMetadataFactory.*;

import com.mysema.query.types.path.*;

import com.mysema.query.types.PathMetadata;
import javax.annotation.Generated;
import com.mysema.query.types.Path;


/**
 * QHashtag is a Querydsl query type for Hashtag
 */
@Generated("com.mysema.query.codegen.EntitySerializer")
public class QHashtag extends EntityPathBase<Hashtag> {

    private static final long serialVersionUID = -195923606L;

    public static final QHashtag hashtag = new QHashtag("hashtag");

    public final QModel _super = new QModel(this);

    public final StringPath hash = createString("hash");

    //inherited
    public final StringPath id = _super.id;

    //inherited
    public final DateTimePath<java.util.Date> lastUpTime = _super.lastUpTime;

    public final StringPath type = createString("type");

    public QHashtag(String variable) {
        super(Hashtag.class, forVariable(variable));
    }

    public QHashtag(Path<? extends Hashtag> path) {
        super(path.getType(), path.getMetadata());
    }

    public QHashtag(PathMetadata<?> metadata) {
        super(Hashtag.class, metadata);
    }

}

