package com.vn.ntt.entity;

import static com.mysema.query.types.PathMetadataFactory.*;

import com.mysema.query.types.path.*;

import com.mysema.query.types.PathMetadata;
import javax.annotation.Generated;
import com.mysema.query.types.Path;
import com.mysema.query.types.path.PathInits;


/**
 * QBuddy is a Querydsl query type for Buddy
 */
@Generated("com.mysema.query.codegen.EntitySerializer")
public class QBuddy extends EntityPathBase<Buddy> {

    private static final long serialVersionUID = -2061027356L;

    public static final QBuddy buddy = new QBuddy("buddy");

    public final QModel _super = new QModel(this);

    public final NumberPath<Double> distance = createNumber("distance", Double.class);

    public final ListPath<Hashtag, QHashtag> hashtags = this.<Hashtag, QHashtag>createList("hashtags", Hashtag.class, QHashtag.class, PathInits.DIRECT2);

    //inherited
    public final StringPath id = _super.id;

    //inherited
    public final DateTimePath<java.util.Date> lastUpTime = _super.lastUpTime;

    public final ArrayPath<double[], Double> location = createArray("location", double[].class);

    public final StringPath name = createString("name");

    public final EnumPath<com.vn.ntt.enums.PokeType> pokeType = createEnum("pokeType", com.vn.ntt.enums.PokeType.class);

    public final NumberPath<Double> radius = createNumber("radius", Double.class);

    public final StringPath token = createString("token");

    public QBuddy(String variable) {
        super(Buddy.class, forVariable(variable));
    }

    public QBuddy(Path<? extends Buddy> path) {
        super(path.getType(), path.getMetadata());
    }

    public QBuddy(PathMetadata<?> metadata) {
        super(Buddy.class, metadata);
    }

}

