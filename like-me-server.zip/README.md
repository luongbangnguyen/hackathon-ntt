# hackathon-ntt
- To run project you must install Gradle (http://gradle.org/) then execute ```gradle bootrun``` 
- Configure database in file ```src/main/resources/application.properties```
